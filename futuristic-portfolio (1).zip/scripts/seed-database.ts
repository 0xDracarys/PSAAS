#!/usr/bin/env tsx

import { MongoClient } from "mongodb"
import { config } from "dotenv"

// Load environment variables
config({ path: ".env.local" })

const MONGODB_URI = process.env.MONGODB_URI
const MONGODB_DB = process.env.MONGODB_DB || "portfolio_db"

if (!MONGODB_URI) {
  throw new Error("Please define the MONGODB_URI environment variable")
}

const sampleProjects = [
  {
    title: "CyberGuard Pro",
    description: "Advanced vulnerability assessment and penetration testing platform",
    longDescription:
      "A comprehensive cybersecurity platform that automates vulnerability assessments, conducts penetration testing, and provides detailed security reports. Built with real-time threat detection and AI-powered risk analysis.",
    technologies: ["Python", "Django", "PostgreSQL", "Redis", "Docker", "AWS"],
    features: [
      "Automated vulnerability scanning",
      "Real-time threat detection",
      "AI-powered risk analysis",
      "Comprehensive security reports",
      "Multi-tenant architecture",
    ],
    githubUrl: "https://github.com/shubhambhasker/cyberguard-pro",
    liveUrl: "https://cyberguard-pro.vercel.app",
    imageUrl: "/cybersecurity-vulnerability-assessment-dashboard-w.jpg",
    category: "cybersecurity",
    status: "completed",
    priority: 1,
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-12-20"),
  },
  {
    title: "BugBounty Analytics",
    description: "Analytics dashboard for bug bounty hunters and security researchers",
    longDescription:
      "A powerful analytics platform designed for bug bounty hunters to track their progress, analyze vulnerability trends, and optimize their hunting strategies with data-driven insights.",
    technologies: ["React", "Node.js", "MongoDB", "Express", "Chart.js", "JWT"],
    features: [
      "Progress tracking and analytics",
      "Vulnerability trend analysis",
      "Earnings optimization",
      "Platform integration",
      "Custom reporting",
    ],
    githubUrl: "https://github.com/shubhambhasker/bugbounty-analytics",
    liveUrl: "https://bugbounty-analytics.vercel.app",
    imageUrl: "/bug-bounty-analytics-dashboard-with-charts-and-gra.jpg",
    category: "cybersecurity",
    status: "completed",
    priority: 2,
    createdAt: new Date("2024-03-10"),
    updatedAt: new Date("2024-11-15"),
  },
  // Add more sample projects as needed
]

const sampleClientRequests = [
  {
    name: "John Doe",
    email: "john.doe@example.com",
    phone: "+1-555-0123",
    projectType: "E-commerce Website",
    requirements:
      "Need a modern e-commerce platform with payment integration, inventory management, and admin dashboard.",
    referenceLinks: ["https://shopify.com", "https://amazon.com"],
    budgetRange: "2500-5000",
    timeline: "3-4 months",
    files: [],
    termsAccepted: true,
    paymentTerms: "25% upfront payment required for projects over €500",
    status: "new",
    createdAt: new Date("2024-12-15"),
    updatedAt: new Date("2024-12-15"),
  },
]

async function seedDatabase() {
  const client = new MongoClient(MONGODB_URI)

  try {
    await client.connect()
    console.log("Connected to MongoDB")

    const db = client.db(MONGODB_DB)

    // Seed projects
    const projectsCollection = db.collection("projects")
    await projectsCollection.deleteMany({}) // Clear existing data
    await projectsCollection.insertMany(sampleProjects)
    console.log(`Inserted ${sampleProjects.length} sample projects`)

    // Seed client requests
    const requestsCollection = db.collection("clientRequests")
    await requestsCollection.deleteMany({}) // Clear existing data
    await requestsCollection.insertMany(sampleClientRequests)
    console.log(`Inserted ${sampleClientRequests.length} sample client requests`)

    // Create indexes for better performance
    await projectsCollection.createIndex({ category: 1 })
    await projectsCollection.createIndex({ status: 1 })
    await projectsCollection.createIndex({ createdAt: -1 })

    await requestsCollection.createIndex({ email: 1 })
    await requestsCollection.createIndex({ status: 1 })
    await requestsCollection.createIndex({ createdAt: -1 })

    console.log("Database indexes created")
    console.log("Database seeding completed successfully!")
  } catch (error) {
    console.error("Error seeding database:", error)
    process.exit(1)
  } finally {
    await client.close()
  }
}

// Run the seeding function
seedDatabase()
