"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  Lock,
  User,
  Eye,
  EyeOff,
  Shield,
  BarChart3,
  Users,
  FolderOpen,
  MessageSquare,
  Plus,
  Edit,
  Trash2,
  Search,
  Download,
  Settings,
  LogOut,
} from "lucide-react"

// Mock data for demonstration
const mockProjects = [
  {
    id: 1,
    title: "SecureAuth Dashboard",
    client: "TechCorp Inc.",
    status: "completed",
    budget: "€2,500",
    startDate: "2024-01-15",
    endDate: "2024-02-28",
    progress: 100,
  },
  {
    id: 2,
    title: "Neural Commerce",
    client: "StartupXYZ",
    status: "in-progress",
    budget: "€4,200",
    startDate: "2024-02-01",
    endDate: "2024-03-15",
    progress: 75,
  },
  {
    id: 3,
    title: "CyberGuard Mobile",
    client: "Security Solutions Ltd.",
    status: "pending",
    budget: "€3,800",
    startDate: "2024-03-01",
    endDate: "2024-04-30",
    progress: 0,
  },
]

const mockClientRequests = [
  {
    id: 1,
    name: "John Smith",
    email: "john@example.com",
    projectType: "E-commerce Platform",
    budget: "€1,000 - €2,500",
    status: "new",
    submittedAt: "2024-01-20T10:30:00Z",
    timeline: "2-3 Months",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah@startup.com",
    projectType: "Web Application",
    budget: "€2,500 - €5,000",
    status: "contacted",
    submittedAt: "2024-01-18T14:15:00Z",
    timeline: "1 Month",
  },
  {
    id: 3,
    name: "Mike Chen",
    email: "mike@techfirm.io",
    projectType: "Security Audit",
    budget: "€500 - €1,000",
    status: "proposal-sent",
    submittedAt: "2024-01-15T09:45:00Z",
    timeline: "ASAP",
  },
]

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [showPassword, setShowPassword] = useState(false)
  const [credentials, setCredentials] = useState({ username: "", password: "" })
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate login process
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsLoading(false)
    onLogin()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-md"
      >
        <Card className="glassmorphism bg-card/10 border-border/30 p-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: "spring" }}
            className="text-center mb-8"
          >
            <Shield className="h-16 w-16 text-primary mx-auto mb-4" />
            <h1 className="text-3xl font-serif font-bold mb-2">Admin Portal</h1>
            <p className="text-muted-foreground">Secure access to project management</p>
          </motion.div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="username"
                  type="text"
                  value={credentials.username}
                  onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                  placeholder="Enter username"
                  className="glassmorphism bg-input/50 pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={credentials.password}
                  onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                  placeholder="Enter password"
                  className="glassmorphism bg-input/50 pl-10 pr-10"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full glow hover:glow-amber transition-all duration-300"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Authenticating...
                </>
              ) : (
                <>
                  <Shield className="h-4 w-4 mr-2" />
                  Secure Login
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-muted-foreground">
            <div className="flex items-center justify-center gap-2">
              <Lock className="h-3 w-3" />
              <span>Protected by advanced encryption</span>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  )
}

function DashboardStats() {
  const stats = [
    {
      title: "Active Projects",
      value: "3",
      change: "+1 this month",
      icon: FolderOpen,
      color: "text-primary",
    },
    {
      title: "Client Requests",
      value: "12",
      change: "+4 this week",
      icon: MessageSquare,
      color: "text-secondary",
    },
    {
      title: "Revenue (YTD)",
      value: "€24,500",
      change: "+15% vs last year",
      icon: BarChart3,
      color: "text-primary",
    },
    {
      title: "Client Satisfaction",
      value: "98%",
      change: "Excellent rating",
      icon: Users,
      color: "text-secondary",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Card className="glassmorphism bg-card/10 border-border/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">{stat.title}</p>
                <p className="text-2xl font-serif font-bold">{stat.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{stat.change}</p>
              </div>
              <stat.icon className={`h-8 w-8 ${stat.color}`} />
            </div>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}

function ProjectsTab() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Completed</Badge>
      case "in-progress":
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">In Progress</Badge>
      case "pending":
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Pending</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const filteredProjects = mockProjects.filter((project) => {
    const matchesSearch =
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.client.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || project.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex gap-4 items-center">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search projects..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="glassmorphism bg-input/50 pl-10 w-64"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="glassmorphism bg-input/50 border border-border/30 rounded-md px-3 py-2 text-sm"
          >
            <option value="all">All Status</option>
            <option value="completed">Completed</option>
            <option value="in-progress">In Progress</option>
            <option value="pending">Pending</option>
          </select>
        </div>

        <Button className="glow hover:glow-amber transition-all duration-300">
          <Plus className="h-4 w-4 mr-2" />
          New Project
        </Button>
      </div>

      {/* Projects Table */}
      <Card className="glassmorphism bg-card/10 border-border/30">
        <Table>
          <TableHeader>
            <TableRow className="border-border/30">
              <TableHead>Project</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Budget</TableHead>
              <TableHead>Timeline</TableHead>
              <TableHead>Progress</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProjects.map((project) => (
              <TableRow key={project.id} className="border-border/30">
                <TableCell className="font-medium">{project.title}</TableCell>
                <TableCell>{project.client}</TableCell>
                <TableCell>{getStatusBadge(project.status)}</TableCell>
                <TableCell>{project.budget}</TableCell>
                <TableCell>
                  <div className="text-sm">
                    <div>{new Date(project.startDate).toLocaleDateString()}</div>
                    <div className="text-muted-foreground">to {new Date(project.endDate).toLocaleDateString()}</div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary transition-all duration-300"
                        style={{ width: `${project.progress}%` }}
                      />
                    </div>
                    <span className="text-sm">{project.progress}%</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  )
}

function ClientRequestsTab() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">New</Badge>
      case "contacted":
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Contacted</Badge>
      case "proposal-sent":
        return <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">Proposal Sent</Badge>
      case "accepted":
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Accepted</Badge>
      case "declined":
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Declined</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const filteredRequests = mockClientRequests.filter((request) => {
    const matchesSearch =
      request.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.projectType.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || request.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="flex gap-4 items-center">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search requests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="glassmorphism bg-input/50 pl-10 w-64"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="glassmorphism bg-input/50 border border-border/30 rounded-md px-3 py-2 text-sm"
          >
            <option value="all">All Status</option>
            <option value="new">New</option>
            <option value="contacted">Contacted</option>
            <option value="proposal-sent">Proposal Sent</option>
            <option value="accepted">Accepted</option>
            <option value="declined">Declined</option>
          </select>
        </div>

        <Button variant="outline" className="glassmorphism bg-transparent">
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>

      {/* Requests Table */}
      <Card className="glassmorphism bg-card/10 border-border/30">
        <Table>
          <TableHeader>
            <TableRow className="border-border/30">
              <TableHead>Client</TableHead>
              <TableHead>Project Type</TableHead>
              <TableHead>Budget</TableHead>
              <TableHead>Timeline</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRequests.map((request) => (
              <TableRow key={request.id} className="border-border/30">
                <TableCell>
                  <div>
                    <div className="font-medium">{request.name}</div>
                    <div className="text-sm text-muted-foreground">{request.email}</div>
                  </div>
                </TableCell>
                <TableCell>{request.projectType}</TableCell>
                <TableCell>{request.budget}</TableCell>
                <TableCell>{request.timeline}</TableCell>
                <TableCell>{getStatusBadge(request.status)}</TableCell>
                <TableCell>
                  <div className="text-sm">
                    <div>{new Date(request.submittedAt).toLocaleDateString()}</div>
                    <div className="text-muted-foreground">{new Date(request.submittedAt).toLocaleTimeString()}</div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="glassmorphism bg-card/95 border-border/50 max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Client Request Details</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Name</Label>
                              <p className="font-medium">{request.name}</p>
                            </div>
                            <div>
                              <Label>Email</Label>
                              <p className="font-medium">{request.email}</p>
                            </div>
                            <div>
                              <Label>Project Type</Label>
                              <p className="font-medium">{request.projectType}</p>
                            </div>
                            <div>
                              <Label>Budget</Label>
                              <p className="font-medium">{request.budget}</p>
                            </div>
                          </div>
                          <div className="flex gap-2 pt-4">
                            <Button className="flex-1">Send Proposal</Button>
                            <Button variant="outline" className="flex-1 bg-transparent">
                              Mark as Contacted
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button variant="ghost" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  )
}

function AdminDashboard({ onLogout }: { onLogout: () => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      {/* Header */}
      <header className="glassmorphism bg-card/10 border-b border-border/30 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-xl font-serif font-bold">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Project Management Portal</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={onLogout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <DashboardStats />

          <Tabs defaultValue="projects" className="space-y-6">
            <TabsList className="glassmorphism bg-card/10 border border-border/30">
              <TabsTrigger value="projects" className="data-[state=active]:bg-primary/20">
                <FolderOpen className="h-4 w-4 mr-2" />
                Projects
              </TabsTrigger>
              <TabsTrigger value="requests" className="data-[state=active]:bg-primary/20">
                <MessageSquare className="h-4 w-4 mr-2" />
                Client Requests
              </TabsTrigger>
            </TabsList>

            <TabsContent value="projects">
              <ProjectsTab />
            </TabsContent>

            <TabsContent value="requests">
              <ClientRequestsTab />
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  )
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  return (
    <AnimatePresence mode="wait">
      {isAuthenticated ? (
        <AdminDashboard key="dashboard" onLogout={() => setIsAuthenticated(false)} />
      ) : (
        <LoginScreen key="login" onLogin={() => setIsAuthenticated(true)} />
      )}
    </AnimatePresence>
  )
}
