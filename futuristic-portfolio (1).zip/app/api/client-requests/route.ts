// API route for handling client requests
// This will be connected to MongoDB Atlas when backend is implemented

import { type NextRequest, NextResponse } from "next/server"
import type { ClientRequest } from "@/lib/mongodb"

// POST - Create new client request
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    const requiredFields = [
      "name",
      "email",
      "phone",
      "projectType",
      "requirements",
      "budget",
      "timeline",
      "acceptedTerms",
    ]
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json({ error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    // Calculate payment terms based on budget
    let paymentTerms = ""
    const budgetValue = Number.parseInt(body.budget.replace(/[^0-9]/g, ""))

    if (budgetValue > 500) {
      paymentTerms = "25% upfront payment required"
    } else {
      paymentTerms = "35-40% upfront payment required"
    }

    // TODO: Replace with actual database call when MongoDB Atlas is connected
    // const requestId = await dbService.createClientRequest({
    //   ...body,
    //   paymentTerms
    // })

    // Mock response for now
    const mockRequestId = `req_${Date.now()}`

    console.log("[v0] Client request received:", {
      id: mockRequestId,
      name: body.name,
      email: body.email,
      projectType: body.projectType,
      budget: body.budget,
      paymentTerms,
    })

    return NextResponse.json({
      success: true,
      requestId: mockRequestId,
      message: "Client request submitted successfully",
      paymentTerms,
    })
  } catch (error) {
    console.error("[v0] Error creating client request:", error)
    return NextResponse.json({ error: "Failed to submit client request" }, { status: 500 })
  }
}

// GET - Retrieve client requests (admin only)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "50")
    const skip = Number.parseInt(searchParams.get("skip") || "0")

    // TODO: Add authentication middleware for admin access
    // TODO: Replace with actual database call when MongoDB Atlas is connected
    // const requests = await dbService.getClientRequests(limit, skip)

    // Mock data for now
    const mockRequests: ClientRequest[] = [
      {
        _id: "req_1",
        name: "John Doe",
        email: "john@example.com",
        phone: "+1234567890",
        projectType: "E-commerce Website",
        requirements: "Need a modern e-commerce platform with payment integration",
        budget: "€2000-€5000",
        timeline: "2-3 months",
        acceptedTerms: true,
        paymentTerms: "25% upfront payment required",
        createdAt: new Date(),
        status: "pending",
      },
    ]

    return NextResponse.json({
      success: true,
      requests: mockRequests,
      total: mockRequests.length,
    })
  } catch (error) {
    console.error("[v0] Error fetching client requests:", error)
    return NextResponse.json({ error: "Failed to fetch client requests" }, { status: 500 })
  }
}
