// API route for handling projects
// This will be connected to MongoDB Atlas when backend is implemented

import { type NextRequest, NextResponse } from "next/server"
import type { Project } from "@/lib/mongodb"

// GET - Retrieve projects
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const activeOnly = searchParams.get("active") === "true"

    // TODO: Replace with actual database call when MongoDB Atlas is connected
    // const projects = await dbService.getProjects(activeOnly)

    // Mock data for now - using the real projects from the frontend
    const mockProjects: Project[] = [
      {
        _id: "proj_1",
        title: "Vulnerability Assessment Platform",
        description: "Automated vulnerability scanning and assessment tool",
        image: "/cybersecurity-network.png",
        tags: ["Python", "Django", "PostgreSQL", "Security"],
        github: "https://github.com/0xDracarys/vulnerability-platform",
        demo: "https://vuln-platform-demo.netlify.app",
        features: ["Automated scanning", "Real-time detection", "Security reports"],
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]

    return NextResponse.json({
      success: true,
      projects: mockProjects,
    })
  } catch (error) {
    console.error("[v0] Error fetching projects:", error)
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 })
  }
}

// POST - Create new project (admin only)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // TODO: Add authentication middleware for admin access
    // TODO: Replace with actual database call when MongoDB Atlas is connected
    // const projectId = await dbService.createProject(body)

    const mockProjectId = `proj_${Date.now()}`

    console.log("[v0] Project created:", {
      id: mockProjectId,
      title: body.title,
    })

    return NextResponse.json({
      success: true,
      projectId: mockProjectId,
      message: "Project created successfully",
    })
  } catch (error) {
    console.error("[v0] Error creating project:", error)
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 })
  }
}
