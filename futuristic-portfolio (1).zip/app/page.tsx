"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Stars, Float } from "@react-three/drei"
import { Suspense, useRef, useState, useEffect } from "react"
import { motion, useInView } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { ClientRequestForm } from "@/components/client-request-form"
import {
  ChevronDown,
  Github,
  Linkedin,
  Mail,
  Code,
  Shield,
  Zap,
  ExternalLink,
  Eye,
  Globe,
  Music,
  Play,
  Pause,
  Volume2,
  Heart,
  Coffee,
  Camera,
  Headphones,
  Send,
  MessageCircle,
  Phone,
  MapPin,
} from "lucide-react"

// 3D Scene Component
function Scene() {
  const meshRef = useRef<any>()

  return (
    <>
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#dc2626" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#f59e0b" />

      <Float speed={2} rotationIntensity={1} floatIntensity={2}>
        <mesh ref={meshRef} position={[0, 0, 0]}>
          <torusGeometry args={[1, 0.3, 16, 100]} />
          <meshStandardMaterial color="#dc2626" emissive="#dc2626" emissiveIntensity={0.2} />
        </mesh>
      </Float>

      <Float speed={1.5} rotationIntensity={0.5} floatIntensity={1}>
        <mesh position={[3, 2, -2]}>
          <octahedronGeometry args={[0.5]} />
          <meshStandardMaterial color="#f59e0b" emissive="#f59e0b" emissiveIntensity={0.3} />
        </mesh>
      </Float>

      <Float speed={2.5} rotationIntensity={1.5} floatIntensity={3}>
        <mesh position={[-3, -1, -1]}>
          <icosahedronGeometry args={[0.3]} />
          <meshStandardMaterial color="#dc2626" emissive="#dc2626" emissiveIntensity={0.4} />
        </mesh>
      </Float>

      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
    </>
  )
}

// Animated Tagline Component
function AnimatedTagline() {
  const skills = [
    "Cybersecurity Expert",
    "Bug Hunter",
    "Customer Success Manager",
    "Security Researcher",
    "Penetration Tester",
  ]

  const [currentSkill, setCurrentSkill] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSkill((prev) => (prev + 1) % skills.length)
    }, 3000)

    return () => clearInterval(interval)
  }, [skills.length])

  return (
    <motion.div
      key={currentSkill}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="text-2xl md:text-4xl font-serif font-bold text-primary text-glow"
    >
      {skills[currentSkill]}
    </motion.div>
  )
}

// Particle Background Component
function ParticleBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-primary rounded-full"
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          animate={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
      ))}
    </div>
  )
}

// Skills Visualization Component
function SkillsVisualization() {
  const skillsData = [
    { name: "Cybersecurity & Penetration Testing", level: 95 },
    { name: "Bug Hunting & Vulnerability Assessment", level: 92 },
    { name: "Customer Success Management", level: 88 },
    { name: "Network Security & SIEM/SOAR", level: 87 },
    { name: "Python & Bash Scripting", level: 85 },
    { name: "Cloud Security (AWS/Azure)", level: 82 },
  ]

  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <div ref={ref} className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {skillsData.map((skill, index) => (
        <motion.div
          key={skill.name}
          initial={{ opacity: 0, x: -50 }}
          animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
          className="glassmorphism bg-card/10 p-6 rounded-lg border border-border/30"
        >
          <div className="flex items-center gap-3 mb-4">
            <Code className={`h-6 w-6 text-primary`} />
            <h3 className="font-serif font-semibold text-lg">{skill.name}</h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Proficiency</span>
              <span className="text-foreground font-medium">{skill.level}%</span>
            </div>
            <motion.div
              initial={{ width: 0 }}
              animate={isInView ? { width: "100%" } : { width: 0 }}
              transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
            >
              <Progress value={skill.level} className="h-2" />
            </motion.div>
          </div>
        </motion.div>
      ))}
    </div>
  )
}

// Timeline Component
function Timeline() {
  const timelineData = [
    {
      year: "2024",
      title: "Customer Success Manager",
      company: "CyberCare (NordVPN)",
      description: "Leading customer success initiatives and security consulting for enterprise clients.",
    },
    {
      year: "2020",
      title: "Security Researcher & Bug Hunter",
      company: "Bugcrowd",
      description: "Achieved Top 300 ranking with 30% increase in identified vulnerabilities.",
    },
    {
      year: "2021",
      title: "TryHackMe Top 5 Lithuania",
      company: "TryHackMe Platform",
      description: "Maintained consistent top 5 ranking in Lithuania and achieved global top 250.",
    },
    {
      year: "2018",
      title: "Bachelor's in Science",
      company: "Siddhi Vinayak Group",
      description: "Completed foundational studies in computer science and information systems.",
    },
  ]

  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <div ref={ref} className="relative">
      {/* Timeline Line */}
      <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-secondary to-primary transform md:-translate-x-1/2" />

      <div className="space-y-8">
        {timelineData.map((item, index) => (
          <motion.div
            key={item.year}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
            transition={{ duration: 0.6, delay: index * 0.2 }}
            className={`relative flex items-center ${index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
          >
            {/* Timeline Dot */}
            <div
              className={`absolute left-4 md:left-1/2 w-4 h-4 rounded-full transform md:-translate-x-1/2 z-10 ${
                true ? "bg-primary glow" : "bg-secondary"
              }`}
            />

            {/* Content Card */}
            <div className={`ml-12 md:ml-0 md:w-5/12 ${index % 2 === 0 ? "md:mr-auto md:pr-8" : "md:ml-auto md:pl-8"}`}>
              <Card className="glassmorphism bg-card/10 border-border/30 p-6">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl font-serif font-bold text-primary">{item.year}</span>
                  <Zap className="h-5 w-5 text-secondary" />
                </div>
                <h3 className="text-xl font-serif font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{item.description}</p>
              </Card>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

// Project Card Component with 3D Hover Effects
function ProjectCard({ project, index }: { project: any; index: number }) {
  const [isHovered, setIsHovered] = useState(false)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50, rotateX: 10 }}
      animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : { opacity: 0, y: 50, rotateX: 10 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="group perspective-1000"
    >
      <motion.div
        animate={{
          rotateY: isHovered ? 5 : 0,
          rotateX: isHovered ? -5 : 0,
          scale: isHovered ? 1.05 : 1,
        }}
        transition={{ duration: 0.3 }}
        className="transform-gpu"
      >
        <Card className="glassmorphism bg-card/10 border-border/30 overflow-hidden h-full hover:glow-amber transition-all duration-300">
          {/* Project Image/Icon */}
          <div className="relative h-48 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center overflow-hidden">
            <motion.div
              animate={{ scale: isHovered ? 1.1 : 1, rotate: isHovered ? 5 : 0 }}
              transition={{ duration: 0.3 }}
            >
              <Code className="h-16 w-16 text-primary" />
            </motion.div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            <div className="absolute top-4 right-4">
              <Badge variant="secondary" className="glassmorphism">
                {project.tags[0]}
              </Badge>
            </div>
          </div>

          {/* Project Content */}
          <div className="p-6">
            <h3 className="text-xl font-serif font-bold mb-2 group-hover:text-primary transition-colors">
              {project.title}
            </h3>
            <p className="text-muted-foreground mb-4 line-clamp-2 leading-relaxed">{project.description}</p>

            {/* Tech Stack */}
            <div className="flex flex-wrap gap-2 mb-4">
              {project.tags.slice(0, 3).map((tech: string) => (
                <Badge key={tech} variant="outline" className="text-xs">
                  {tech}
                </Badge>
              ))}
              {project.tags.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{project.tags.length - 3} more
                </Badge>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </DialogTrigger>
                <DialogContent className="glassmorphism bg-card/95 border-border/50 max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-serif flex items-center gap-3">
                      <Code className="h-8 w-8 text-primary" />
                      {project.title}
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6">
                    {/* Project Image */}
                    <div className="relative h-64 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center">
                      <Code className="h-24 w-24 text-primary" />
                    </div>

                    {/* Description */}
                    <div>
                      <h4 className="font-serif font-semibold mb-2">About This Project</h4>
                      <p className="text-muted-foreground leading-relaxed">{project.description}</p>
                    </div>

                    {/* Tech Stack */}
                    <div>
                      <h4 className="font-serif font-semibold mb-3">Technologies Used</h4>
                      <div className="flex flex-wrap gap-2">
                        {project.tags.map((tech: string) => (
                          <Badge key={tech} variant="secondary">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Features */}
                    <div>
                      <h4 className="font-serif font-semibold mb-3">Key Features</h4>
                      <ul className="space-y-2">
                        {project.features.map((feature: string, idx: number) => (
                          <li key={idx} className="flex items-start gap-2 text-muted-foreground">
                            <Zap className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Links */}
                    <div className="flex gap-3 pt-4">
                      <Button className="flex-1" asChild>
                        <a href={project.demo} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Live Demo
                        </a>
                      </Button>
                      <Button variant="outline" className="flex-1 bg-transparent" asChild>
                        <a href={project.github} target="_blank" rel="noopener noreferrer">
                          <Github className="h-4 w-4" />
                          Source Code
                        </a>
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Button variant="outline" size="sm" asChild>
                <a href={project.github} target="_blank" rel="noopener noreferrer">
                  <Github className="h-4 w-4" />
                </a>
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// Projects Portfolio Component
function ProjectsPortfolio() {
  const projects = [
    {
      id: 1,
      title: "Vulnerability Assessment Platform",
      description:
        "Automated vulnerability scanning and assessment tool designed for comprehensive security analysis. Features real-time threat detection, detailed reporting, and integration with popular security frameworks.",
      image: "/cybersecurity-vulnerability-assessment-dashboard-w.jpg",
      tags: ["Python", "Django", "PostgreSQL", "Security", "Automation"],
      github: "https://github.com/0xDracarys/vulnerability-platform",
      demo: "https://vuln-platform-demo.netlify.app",
      features: [
        "Automated vulnerability scanning",
        "Real-time threat detection",
        "Comprehensive security reports",
        "Integration with security frameworks",
        "Custom rule engine",
      ],
    },
    {
      id: 2,
      title: "Bugcrowd Analytics Dashboard",
      description:
        "Advanced analytics platform for bug bounty programs with data visualization, performance tracking, and automated reporting. Helps researchers and companies optimize their security programs.",
      image: "/bug-bounty-analytics-dashboard-with-charts-and-gra.jpg",
      tags: ["React", "Node.js", "MongoDB", "Analytics", "D3.js"],
      github: "https://github.com/0xDracarys/bugcrowd-analytics",
      demo: "https://bugcrowd-analytics-demo.netlify.app",
      features: [
        "Real-time analytics dashboard",
        "Performance tracking metrics",
        "Automated report generation",
        "Data visualization tools",
        "API integration with Bugcrowd",
      ],
    },
    {
      id: 3,
      title: "Customer Support Automation",
      description:
        "AI-powered customer support system leveraging machine learning for intelligent ticket routing, automated responses, and sentiment analysis. Built for CyberCare operations.",
      image: "/ai-customer-support-dashboard.png",
      tags: ["Next.js", "Python", "OpenAI", "AI/ML", "Customer Success"],
      github: "https://github.com/0xDracarys/support-automation",
      demo: "https://support-ai-demo.netlify.app",
      features: [
        "AI-powered ticket routing",
        "Automated response generation",
        "Sentiment analysis",
        "Multi-language support",
        "Performance analytics",
      ],
    },
    {
      id: 4,
      title: "Security Research Lab",
      description:
        "Interactive platform for cybersecurity research and training. Features virtual labs, exploit development environments, and collaborative research tools for security professionals.",
      image: "/cybersecurity-research-lab-interface-with-terminal.jpg",
      tags: ["React", "Docker", "Kubernetes", "Security", "DevOps"],
      github: "https://github.com/0xDracarys/security-lab",
      demo: "https://security-lab-demo.netlify.app",
      features: [
        "Virtual security labs",
        "Exploit development environment",
        "Collaborative research tools",
        "Containerized environments",
        "Real-time collaboration",
      ],
    },
    {
      id: 5,
      title: "TryHackMe Leaderboard Tracker",
      description:
        "Personal tracking system for TryHackMe progress with advanced analytics, goal setting, and performance visualization. Helped achieve Top 5 Lithuania ranking.",
      image: "/tryhackme-progress-tracker-with-leaderboard-and-st.jpg",
      tags: ["Python", "Selenium", "FastAPI", "Data Analysis", "Automation"],
      github: "https://github.com/0xDracarys/tryhackme-tracker",
      demo: "https://thm-tracker-demo.netlify.app",
      features: [
        "Progress tracking automation",
        "Leaderboard monitoring",
        "Performance analytics",
        "Goal setting and reminders",
        "Achievement visualization",
      ],
    },
    {
      id: 6,
      title: "Custom Linux Security Build",
      description:
        "Custom Linux distribution optimized for security and penetration testing. Features pre-configured security tools, hardened kernel, and specialized environments for security research.",
      image: "/custom-linux-desktop-with-security-tools-and-termi.jpg",
      tags: ["Linux", "C", "Bash", "Security", "System Administration"],
      github: "https://github.com/0xDracarys/secure-linux",
      demo: "https://secure-linux-demo.netlify.app",
      features: [
        "Hardened Linux kernel",
        "Pre-configured security tools",
        "Penetration testing environment",
        "Custom security scripts",
        "Optimized for research",
      ],
    },
  ]

  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} className="py-20 px-4 relative">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-foreground">
            Featured <span className="text-primary text-glow">Projects</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
            Explore my latest work in cybersecurity, web development, and innovative digital solutions. Each project
            represents a unique challenge solved with cutting-edge technology and creative thinking.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>

        {/* View More Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-12"
        >
          <Button
            size="lg"
            variant="outline"
            className="glassmorphism hover:glow-amber transition-all duration-300 bg-transparent"
          >
            <Github className="h-5 w-5 mr-2" />
            View All Projects on GitHub
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

// Personal Showcase Component
function PersonalShowcase() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTrack, setCurrentTrack] = useState(0)
  const videoRef = useRef<HTMLVideoElement>(null)

  const guitarTracks = [
    {
      title: "Neon Dreams",
      description: "An ambient guitar piece inspired by cyberpunk aesthetics",
      duration: "3:42",
      genre: "Ambient Rock",
    },
    {
      title: "Digital Echoes",
      description: "Electronic guitar fusion with synthesized elements",
      duration: "4:15",
      genre: "Electronic Rock",
    },
    {
      title: "Code & Strings",
      description: "A melodic journey through the intersection of music and technology",
      duration: "5:23",
      genre: "Progressive",
    },
  ]

  const personalInterests = [
    {
      icon: Music,
      title: "Guitar Playing",
      description: "Creating ambient and electronic music that bridges the gap between technology and emotion.",
      color: "text-primary",
    },
    {
      icon: Coffee,
      title: "Coffee Brewing",
      description: "Perfecting the art of pour-over coffee, much like debugging code - precision matters.",
      color: "text-secondary",
    },
    {
      icon: Camera,
      title: "Photography",
      description: "Capturing the beauty in technology and urban landscapes through a cyberpunk lens.",
      color: "text-primary",
    },
    {
      icon: Headphones,
      title: "Music Production",
      description: "Experimenting with electronic music production and sound design in my home studio.",
      color: "text-secondary",
    },
  ]

  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  return (
    <section ref={ref} className="py-20 px-4 relative bg-gradient-to-br from-muted/10 to-background">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-foreground">
            Beyond <span className="text-secondary text-glow">Code</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
            When I step away from the keyboard, I find inspiration in music, creativity, and the analog world. Here's a
            glimpse into the personal side that fuels my professional passion.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Guitar Showcase */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Card className="glassmorphism bg-card/10 border-border/30 overflow-hidden">
              {/* Video Player */}
              <div className="relative aspect-video bg-gradient-to-br from-primary/20 to-secondary/20">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  poster="/guitarist-playing-electric-guitar-in-neon-lit-stud.jpg"
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                >
                  <source src="/guitar-performance.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>

                {/* Video Controls Overlay */}
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300">
                  <Button
                    size="lg"
                    onClick={togglePlay}
                    className="glassmorphism bg-card/20 hover:bg-card/40 border-border/50"
                  >
                    {isPlaying ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8" />}
                  </Button>
                </div>

                {/* Now Playing Indicator */}
                <div className="absolute top-4 left-4 glassmorphism bg-card/20 px-3 py-1 rounded-full">
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-4 bg-primary rounded-full animate-pulse" />
                    <span>Live Performance</span>
                  </div>
                </div>
              </div>

              {/* Track List */}
              <div className="p-6">
                <h3 className="text-2xl font-serif font-bold mb-4 flex items-center gap-3">
                  <Music className="h-6 w-6 text-primary" />
                  Guitar Sessions
                </h3>

                <div className="space-y-3">
                  {guitarTracks.map((track, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                      transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                      className={`glassmorphism bg-card/5 p-4 rounded-lg border border-border/20 cursor-pointer hover:bg-card/10 transition-all duration-300 ${
                        currentTrack === index ? "ring-2 ring-primary/50" : ""
                      }`}
                      onClick={() => setCurrentTrack(index)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-serif font-semibold text-foreground">{track.title}</h4>
                          <p className="text-sm text-muted-foreground mb-1">{track.description}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>{track.genre}</span>
                            <span>{track.duration}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {currentTrack === index && (
                            <div className="flex items-center gap-1">
                              <div className="w-1 h-4 bg-primary animate-pulse" />
                              <div className="w-1 h-6 bg-primary animate-pulse" style={{ animationDelay: "0.1s" }} />
                              <div className="w-1 h-3 bg-primary animate-pulse" style={{ animationDelay: "0.2s" }} />
                            </div>
                          )}
                          <Volume2 className="h-4 w-4 text-secondary" />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Personal Interests */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-serif font-bold mb-6 flex items-center gap-3">
              <Heart className="h-6 w-6 text-primary" />
              Passions & Interests
            </h3>

            {personalInterests.map((interest, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
              >
                <Card className="glassmorphism bg-card/10 border-border/30 p-6 hover:glow-amber transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="glassmorphism bg-card/20 p-3 rounded-lg">
                      <interest.icon className={`h-6 w-6 ${interest.color}`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-serif font-semibold text-lg mb-2">{interest.title}</h4>
                      <p className="text-muted-foreground leading-relaxed">{interest.description}</p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}

            {/* Personal Quote */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.8, delay: 1 }}
            >
              <Card className="glassmorphism bg-gradient-to-br from-primary/10 to-secondary/10 border-border/30 p-8 text-center">
                <blockquote className="text-lg font-serif italic text-foreground mb-4">
                  "Music and code share the same DNA - they're both about creating something beautiful from structured
                  chaos."
                </blockquote>
                <cite className="text-muted-foreground">- Alex, Developer & Musician</cite>
              </Card>
            </motion.div>
          </motion.div>
        </div>

        {/* Creative Process Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="text-center"
        >
          <Card className="glassmorphism bg-card/10 border-border/30 p-8 md:p-12">
            <h3 className="text-3xl font-serif font-bold mb-6">
              The Creative <span className="text-primary">Process</span>
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-4xl mx-auto mb-8">
              Whether I'm debugging complex security vulnerabilities or composing a new guitar piece, the process
              remains the same: start with curiosity, iterate with purpose, and never stop learning. This creative
              mindset flows seamlessly between my professional work and personal passions, creating a synergy that
              drives innovation in both domains.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <Badge variant="secondary" className="glassmorphism text-base px-4 py-2">
                Creative Problem Solving
              </Badge>
              <Badge variant="outline" className="glassmorphism text-base px-4 py-2">
                Continuous Learning
              </Badge>
              <Badge variant="secondary" className="glassmorphism text-base px-4 py-2">
                Artistic Expression
              </Badge>
              <Badge variant="outline" className="glassmorphism text-base px-4 py-2">
                Technical Innovation
              </Badge>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  )
}

// Enhanced Contact Section Component
function ContactSection() {
  const [showForm, setShowForm] = useState(false)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  const contactMethods = [
    {
      icon: Mail,
      label: "Email",
      value: "shubhambhaskr123@gmail.com",
      href: "mailto:shubhambhaskr123@gmail.com",
      description: "Best for detailed project discussions",
    },
    {
      icon: Phone,
      label: "Phone",
      value: "(+370) 63206160",
      href: "tel:+37063206160",
      description: "Quick calls and consultations",
    },
    {
      icon: MapPin,
      label: "Location",
      value: "Kaunas, Lithuania",
      href: "#",
      description: "Available for local meetings",
    },
  ]

  const socialLinks = [
    {
      icon: Github,
      label: "GitHub",
      href: "https://github.com/0xDracarys",
      color: "hover:text-white",
    },
    {
      icon: Linkedin,
      label: "LinkedIn",
      href: "https://linkedin.com/in/shubham-bhasker",
      color: "hover:text-blue-400",
    },
    {
      icon: Globe,
      label: "Portfolio",
      href: "https://zenithh.netlify.app/",
      color: "hover:text-green-400",
    },
    {
      icon: Shield,
      label: "Bugcrowd",
      href: "https://bugcrowd.com/0xDracarys",
      color: "hover:text-red-400",
    },
  ]

  return (
    <section ref={ref} className="py-20 px-4 relative bg-gradient-to-br from-muted/5 to-background">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-foreground">
            Let's <span className="text-primary text-glow">Connect</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
            Ready to bring your vision to life? Whether you have a detailed project plan or just an idea, I'm here to
            help you build something extraordinary.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Methods */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-serif font-bold mb-6">Get In Touch</h3>

            {contactMethods.map((method, index) => (
              <motion.div
                key={method.label}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.6, delay: 0.4 + index * 0.1 }}
              >
                <Card className="glassmorphism bg-card/10 border-border/30 p-6 hover:glow-amber transition-all duration-300">
                  <a
                    href={method.href}
                    className="flex items-start gap-4 group"
                    target={method.href.startsWith("http") ? "_blank" : undefined}
                    rel={method.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  >
                    <div className="glassmorphism bg-card/20 p-3 rounded-lg group-hover:bg-primary/20 transition-colors">
                      <method.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-serif font-semibold text-lg mb-1">{method.label}</h4>
                      <p className="text-foreground font-medium mb-1">{method.value}</p>
                      <p className="text-sm text-muted-foreground">{method.description}</p>
                    </div>
                  </a>
                </Card>
              </motion.div>
            ))}

            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="pt-6"
            >
              <h4 className="font-serif font-semibold text-lg mb-4">Follow My Journey</h4>
              <div className="flex gap-4">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    initial={{ scale: 0 }}
                    animate={isInView ? { scale: 1 } : { scale: 0 }}
                    transition={{ delay: 1 + index * 0.1, type: "spring" }}
                    className={`glassmorphism bg-card/10 border-border/30 p-4 rounded-lg hover:glow-amber transition-all duration-300 ${social.color}`}
                  >
                    <social.icon className="h-6 w-6" />
                  </motion.a>
                ))}
              </div>
            </motion.div>
          </motion.div>

          {/* CTA Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex items-center"
          >
            <Card className="glassmorphism bg-gradient-to-br from-primary/10 to-secondary/10 border-border/30 p-8 w-full">
              <motion.div
                initial={{ scale: 0 }}
                animate={isInView ? { scale: 1 } : { scale: 0 }}
                transition={{ delay: 0.6, type: "spring" }}
              >
                <MessageCircle className="h-16 w-16 text-primary mx-auto mb-6" />
              </motion.div>

              <h3 className="text-3xl font-serif font-bold mb-4 text-center">
                Start Your <span className="text-primary">Project</span>
              </h3>

              <p className="text-muted-foreground leading-relaxed mb-6 text-center">
                Ready to transform your ideas into reality? Let's discuss your project requirements and create something
                amazing together.
              </p>

              <div className="space-y-4">
                <Button
                  size="lg"
                  onClick={() => setShowForm(true)}
                  className="w-full glow hover:glow-amber transition-all duration-300 text-lg py-3"
                >
                  <Send className="h-5 w-5 mr-2" />
                  Start Project Request
                </Button>

                <Button
                  variant="outline"
                  size="lg"
                  className="w-full glassmorphism hover:glow-amber transition-all duration-300 bg-transparent text-lg py-3"
                  asChild
                >
                  <a href="mailto:shubhambhaskr123@gmail.com">
                    <Mail className="h-5 w-5 mr-2" />
                    Quick Email Instead
                  </a>
                </Button>
              </div>

              <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full" />
                  <span>Free consultation</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-secondary rounded-full" />
                  <span>24-hour response</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full" />
                  <span>NDA available</span>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Client Request Form Modal */}
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogContent className="glassmorphism bg-card/95 border-border/50 max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-3xl font-serif font-bold text-center">
                Let's Build Your <span className="text-primary">Project</span>
              </DialogTitle>
            </DialogHeader>
            <ClientRequestForm />
          </DialogContent>
        </Dialog>
      </div>
    </section>
  )
}

export default function HomePage() {
  return (
    <div className="bg-gradient-to-br from-background via-background to-muted/20">
      {/* Hero Section */}
      <div className="min-h-screen relative overflow-hidden">
        {/* Particle Background */}
        <ParticleBackground />

        {/* 3D Canvas Background */}
        <div className="absolute inset-0 z-0">
          <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
            <Suspense fallback={null}>
              <Scene />
            </Suspense>
          </Canvas>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 min-h-screen flex items-center justify-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="text-center max-w-4xl mx-auto"
          >
            {/* Glassmorphic Hero Card */}
            <Card className="glassmorphism bg-card/10 border-border/30 p-8 md:p-12 backdrop-blur-xl">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="mb-8 flex justify-center"
              >
                <div className="relative">
                  <img
                    src="/hero-img.jpeg"
                    alt="Shubham Bhasker - Cybersecurity Expert"
                    className="w-32 h-32 md:w-40 md:h-40 rounded-full object-cover border-4 border-primary/30 shadow-2xl"
                  />
                  <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-primary/20 to-secondary/20 animate-pulse"></div>
                </div>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.7 }}
                className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold mb-6 text-foreground"
              >
                Hello, I'm <span className="text-primary text-glow">Shubham</span>
              </motion.h1>

              <div className="mb-8 h-16 flex items-center justify-center">
                <AnimatedTagline />
              </div>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 1.2 }}
                className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed max-w-2xl mx-auto"
              >
                Cybersecurity professional and bug hunter crafting secure digital experiences. Currently Customer
                Success Manager at CyberCare (NordVPN), Top 5 TryHackMe Lithuania, and Bugcrowd Top 300 researcher.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.5 }}
                className="flex flex-col sm:flex-row gap-4 justify-center items-center"
              >
                <Button size="lg" className="glow hover:glow-amber transition-all duration-300 text-lg px-8 py-3">
                  Explore My Work
                </Button>

                <div className="flex gap-4">
                  <Button
                    variant="outline"
                    size="icon"
                    className="glassmorphism hover:glow-amber transition-all duration-300 bg-transparent"
                  >
                    <Github className="h-5 w-5" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="glassmorphism hover:glow-amber transition-all duration-300 bg-transparent"
                  >
                    <Linkedin className="h-5 w-5" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="glassmorphism hover:glow-amber transition-all duration-300 bg-transparent"
                  >
                    <Mail className="h-5 w-5" />
                  </Button>
                </div>
              </motion.div>
            </Card>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 2 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            className="flex flex-col items-center text-muted-foreground"
          >
            <span className="text-sm mb-2">Scroll to explore</span>
            <ChevronDown className="h-6 w-6" />
          </motion.div>
        </motion.div>
      </div>

      {/* About Section */}
      <section className="py-20 px-4 relative">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-foreground">
              About <span className="text-primary text-glow">Me</span>
            </h2>
            <div className="max-w-3xl mx-auto">
              <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8">
                I'm Shubham Bhasker, a cybersecurity professional who bridges the gap between security research and
                customer success. Currently pursuing my Bachelor's in Information Systems & Cyber Security at Vilnius
                University while working as a Customer Success Manager at CyberCare (NordVPN).
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                My journey in cybersecurity began with curiosity about how systems work under the hood. This led me to
                become a security researcher and bug hunter, achieving Top 5 ranking in Lithuania on TryHackMe and Top
                300 globally on Bugcrowd with a 30% increase in identified vulnerabilities.
              </p>
              <blockquote className="text-xl italic text-primary border-l-4 border-primary pl-6 mb-8">
                "Security is not a product, but a process. It's about understanding the attacker's mindset and staying
                one step ahead."
              </blockquote>
              <p className="text-lg text-muted-foreground leading-relaxed">
                When I'm not securing systems or helping customers succeed, I enjoy continuous learning, contributing to
                open source security tools, and mentoring aspiring security researchers. My technical approach focuses
                on systematic analysis, vulnerability research, and security innovation.
              </p>
            </div>
          </motion.div>

          {/* Skills Section */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true, margin: "-100px" }}
            className="mb-20"
          >
            <h3 className="text-3xl font-serif font-bold text-center mb-12">
              Technical <span className="text-secondary">Expertise</span>
            </h3>
            <SkillsVisualization />
          </motion.div>

          {/* Timeline Section */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true, margin: "-100px" }}
          >
            <h3 className="text-3xl font-serif font-bold text-center mb-12">
              Professional <span className="text-primary">Journey</span>
            </h3>
            <Timeline />
          </motion.div>
        </div>
      </section>

      {/* Projects Portfolio Section */}
      <ProjectsPortfolio />

      {/* Personal Showcase Section */}
      <PersonalShowcase />

      <ContactSection />
    </div>
  )
}
