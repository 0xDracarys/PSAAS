// MongoDB Atlas connection utility
// This file provides database connection and helper functions for future backend integration

import { MongoClient, type Db, type Collection } from "mongodb"

// MongoDB Atlas connection string - to be set in environment variables
const MONGODB_URI =
  process.env.MONGODB_URI ||
  "mongodb+srv://<username>:<password>@cluster0.mongodb.net/<database>?retryWrites=true&w=majority"
const MONGODB_DB = process.env.MONGODB_DB || "portfolio_db"

// Global variable to cache the database connection
let cachedClient: MongoClient | null = null
let cachedDb: Db | null = null

// Connect to MongoDB Atlas
export async function connectToDatabase(): Promise<{ client: MongoClient; db: Db }> {
  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb }
  }

  try {
    const client = new MongoClient(MONGODB_URI)
    await client.connect()

    const db = client.db(MONGODB_DB)

    cachedClient = client
    cachedDb = db

    return { client, db }
  } catch (error) {
    console.error("Failed to connect to MongoDB:", error)
    throw error
  }
}

// Collection interfaces for type safety
export interface ClientRequest {
  _id?: string
  name: string
  email: string
  phone: string
  projectType: string
  requirements: string
  budget: string
  timeline: string
  referenceLinks?: string[]
  files?: string[]
  acceptedTerms: boolean
  paymentTerms: string
  createdAt: Date
  status: "pending" | "reviewed" | "approved" | "rejected"
}

export interface Project {
  _id?: string
  title: string
  description: string
  image: string
  tags: string[]
  github: string
  demo: string
  features: string[]
  isActive: boolean
  createdAt: Date
  updatedAt: Date
}

export interface AdminUser {
  _id?: string
  username: string
  email: string
  passwordHash: string
  role: "admin" | "user"
  createdAt: Date
  lastLogin?: Date
}

// Helper functions for database operations
export class DatabaseService {
  private db: Db | null = null

  async init() {
    const { db } = await connectToDatabase()
    this.db = db
  }

  // Client Requests operations
  async createClientRequest(request: Omit<ClientRequest, "_id" | "createdAt" | "status">): Promise<string> {
    if (!this.db) await this.init()

    const collection: Collection<ClientRequest> = this.db!.collection("client_requests")
    const result = await collection.insertOne({
      ...request,
      createdAt: new Date(),
      status: "pending",
    })

    return result.insertedId.toString()
  }

  async getClientRequests(limit = 50, skip = 0): Promise<ClientRequest[]> {
    if (!this.db) await this.init()

    const collection: Collection<ClientRequest> = this.db!.collection("client_requests")
    return await collection.find({}).sort({ createdAt: -1 }).limit(limit).skip(skip).toArray()
  }

  async updateClientRequestStatus(id: string, status: ClientRequest["status"]): Promise<boolean> {
    if (!this.db) await this.init()

    const collection: Collection<ClientRequest> = this.db!.collection("client_requests")
    const result = await collection.updateOne({ _id: id }, { $set: { status, updatedAt: new Date() } })

    return result.modifiedCount > 0
  }

  // Projects operations
  async createProject(project: Omit<Project, "_id" | "createdAt" | "updatedAt">): Promise<string> {
    if (!this.db) await this.init()

    const collection: Collection<Project> = this.db!.collection("projects")
    const result = await collection.insertOne({
      ...project,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    return result.insertedId.toString()
  }

  async getProjects(activeOnly = false): Promise<Project[]> {
    if (!this.db) await this.init()

    const collection: Collection<Project> = this.db!.collection("projects")
    const filter = activeOnly ? { isActive: true } : {}

    return await collection.find(filter).sort({ createdAt: -1 }).toArray()
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<boolean> {
    if (!this.db) await this.init()

    const collection: Collection<Project> = this.db!.collection("projects")
    const result = await collection.updateOne({ _id: id }, { $set: { ...updates, updatedAt: new Date() } })

    return result.modifiedCount > 0
  }

  async deleteProject(id: string): Promise<boolean> {
    if (!this.db) await this.init()

    const collection: Collection<Project> = this.db!.collection("projects")
    const result = await collection.deleteOne({ _id: id })

    return result.deletedCount > 0
  }

  // Admin operations
  async createAdminUser(user: Omit<AdminUser, "_id" | "createdAt">): Promise<string> {
    if (!this.db) await this.init()

    const collection: Collection<AdminUser> = this.db!.collection("admin_users")
    const result = await collection.insertOne({
      ...user,
      createdAt: new Date(),
    })

    return result.insertedId.toString()
  }

  async getAdminUser(username: string): Promise<AdminUser | null> {
    if (!this.db) await this.init()

    const collection: Collection<AdminUser> = this.db!.collection("admin_users")
    return await collection.findOne({ username })
  }

  async updateLastLogin(username: string): Promise<boolean> {
    if (!this.db) await this.init()

    const collection: Collection<AdminUser> = this.db!.collection("admin_users")
    const result = await collection.updateOne({ username }, { $set: { lastLogin: new Date() } })

    return result.modifiedCount > 0
  }
}

// Export singleton instance
export const dbService = new DatabaseService()

// Database initialization script for MongoDB Atlas
export const initializeDatabase = async () => {
  try {
    const { db } = await connectToDatabase()

    // Create indexes for better performance
    await db.collection("client_requests").createIndex({ email: 1 })
    await db.collection("client_requests").createIndex({ createdAt: -1 })
    await db.collection("client_requests").createIndex({ status: 1 })

    await db.collection("projects").createIndex({ isActive: 1 })
    await db.collection("projects").createIndex({ createdAt: -1 })

    await db.collection("admin_users").createIndex({ username: 1 }, { unique: true })
    await db.collection("admin_users").createIndex({ email: 1 }, { unique: true })

    console.log("Database initialized successfully")
  } catch (error) {
    console.error("Database initialization failed:", error)
    throw error
  }
}
